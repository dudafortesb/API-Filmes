from db import db                       # DE db IMPORTAR db: importa a instância do SQLAlchemy que gerencia o banco de dados

class filme(db.Model):                   # Define a classe filme como um modelo do SQLAlchemy (herda de db.Model)
    __tablename__ = 'filmes'              # Nome da tabela no banco de dados será "filmes"

    id = db.Column(db.Integer, primary_key=True)          # Coluna "id": número inteiro, chave primária (identificador único)
    modelo = db.Column(db.String(80), nullable=False)     # Coluna "modelo": texto com limite de 80 caracteres, não pode ser nula
    marca = db.Column(db.String(80), nullable=False)      # Coluna "marca": texto com limite de 80 caracteres, não pode ser nula
    ano = db.Column(db.Integer, nullable=False)           # Coluna "ano": número inteiro, não pode ser nulo

    def json(self):                                        # Define o método json() que retorna os dados do filme como dicionário
        return {
            'id': self.id,            # Retorna o ID do filme
            'modelo': self.modelo,    # Retorna o modelo do filme
            'marca': self.marca,      # Retorna a marca do filme
            'ano': self.ano           # Retorna o ano do filme
        }
